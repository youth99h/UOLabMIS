
/*
 * 中北大学软件学院版权所有
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.ychs.uolab.util.DbUtil;

/**
 * 向子表t_major里添加数据
 * @author  侯博文
 * @version 1.0
 */
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("专业号：");
		int majorid = sc.nextInt();
		
		System.out.println("院系号：");
		int deptid = sc.nextInt();
		
		System.out.println("专业名字：");
		String name = sc.next();
		
		System.out.println("备注：");
		String remark = sc.next();
		
		
		Connection conn = DbUtil.getConnection();
		String sql = "INSERT INTO t_major VALUES(?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, majorid);
			pstmt.setInt(2, deptid);
			pstmt.setString(3, name);
			pstmt.setString(4, remark);
			int flag =pstmt.executeUpdate();
			System.out.println(flag);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DbUtil.closeResource(null, null, conn);
		}
		
	}
}
